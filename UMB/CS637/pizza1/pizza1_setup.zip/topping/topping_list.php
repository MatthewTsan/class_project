<?php include '../view/header.php'; ?>
<main>
    <section>
        <h1>Topping List</h1>
        <table>
            <tr>
                <th>Topping Name</th>
                <th>&nbsp;</th>
            </tr>
          
            <?php 
            foreach ($toppings as $topping) : ?>
                <tr>
                    <td><?php echo $topping['topping']; ?></td>
                    <td>TODO: delete button </td>
                </tr>
            <?php endforeach; ?>
        </table>
        <p>
            TODO: Link to Add Topping
        </p>
    </section>
</main>
<?php include '../view/footer.php'; 
