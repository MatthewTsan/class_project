<?php include '../view/header.php'; ?>
<main>
    <section>
        <h1>User List</h1>
    </section>
</main>
<?php include '../view/footer.php'; 