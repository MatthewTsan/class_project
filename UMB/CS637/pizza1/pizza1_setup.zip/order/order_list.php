<?php include '../view/header.php'; ?>
<main>
    <section>
        <h1>Current Orders Report</h1>
        <h2>Orders Baked but not delivered</h2>
        <h2>Orders Preparing(in the oven): Any ready now?</h2>
        <br> 
        <!--Button for marking oldest preparing pizza as baked -->
        <br>  
    </section>
</main>
<?php include '../view/footer.php'; 