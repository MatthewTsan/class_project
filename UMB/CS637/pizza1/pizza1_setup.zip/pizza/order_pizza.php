<?php include '../view/header.php'; ?>
<main>
    <h1> Order Pizza </h1>
</main>
<?php include '../view/footer.php'; 