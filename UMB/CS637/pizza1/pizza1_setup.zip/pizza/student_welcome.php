<?php include '../view/header.php'; ?>
<main>
    <section>
        <h1>Welcome Student!</h1>
        
        <h2>Available Sizes</h2>

        <h2>Available Toppings</h2>

        <h2>Form for user, with select list for registered users </h2>

        <h2>Orders in progress for user </h2>

        <h2> Button to acknowledge receipt of pizzas that are ready </h2>

        <h2> Link to order a pizza </h2>
    </section>
</main>
<?php include '../view/footer.php'; 