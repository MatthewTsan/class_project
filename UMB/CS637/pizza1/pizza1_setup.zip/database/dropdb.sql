-- for use where we can't drop the whole database
-- drop targets of FKs after tables with the FKs
-- if necessary, use --force to get past failing commands
drop table order_topping;	
drop table pizza_orders;
drop table menu_sizes;			
drop table menu_toppings;
drop table shop_users;	
drop table status_values;
drop table pizza_sys_tab;



