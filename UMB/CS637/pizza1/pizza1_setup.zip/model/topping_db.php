<?php
// the try/catch for these actions is in the caller
function add_topping($db, $topping_name)  
{

}

function get_toppings($db) {
    $query = 'SELECT * FROM menu_toppings';
    $statement = $db->prepare($query);
    $statement->execute();
    $toppings = $statement->fetchAll();
    return $toppings;    
}
