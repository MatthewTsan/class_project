<footer>
    <p>
       The Pizza Shop
    </p>
</footer>
</body>
</html>